import axios from 'axios';

const API_URL = 'http://localhost:8080';
const USERNAME = 'Ace';
const PASSWORD = 'Ace';

export const fetchData = async (endpoint) => {
    try {
        const response = await axios.get(`${API_URL}/${endpoint}`, {auth: {
            username: USERNAME,
            password: PASSWORD
        }});
        return response.data;
    } catch (error) {
        throw new Error(error.response.data.message);
    }
};

export const postData = async (endpoint, requestBody) => {
    try {
        const response = await axios.post(`${API_URL}/${endpoint}`, requestBody, {
            auth: {
                username: USERNAME,
                password: PASSWORD
            }
        });
        return response.data;
    } catch (error) {
        console.log('we are inside postdata catch',error);
        throw new Error(error.response.data.message);
    }
};
