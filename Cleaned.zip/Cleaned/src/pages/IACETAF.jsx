import React, { useEffect } from 'react';
import { useState, createContext, useContext } from 'react';

import { Button, Header, MultiSelect, CodeEditor, ToasterPopup} from '../components';
import { useStateContext } from '../contexts/ContextProvider';
import { fetchData, postData } from '../apis/apiServices';
import { Toaster, toast } from 'sonner';
import GridLoader from "react-spinners/ClipLoader";


const IACETAF = () => {  
  const { currentColor, currentMode } = useStateContext();  
  const [windowList, setwindowList] = useState([]);
  const [data, setData] = useState(new Map());
  const newMap = new Map(data);
  const [updateMap, setUpdateMap] = useState(new Map()); 
  const [testDataState, setTestData] = useState(null);
  let testData;
  const [temp, setTemp] = useState('');
  const [temp2, setTemp2] = useState('');
  const [temp3, setTemp3] = useState('');
  let [loading, setLoading] = useState(false);
  
  
  const handleFeatureWindow = (value) => {
    setTemp(value? value:'');
  };

  const handleStepWindow = (value) => {
    setTemp2(value? value:'');
  };

  const handleDataWindow = (value) => {
    setTemp3(value? value:'');
  };

  useEffect(() => {     
    const setWindow = () =>{      
    setwindowList([...temp, ...temp2, ...temp3].filter(Boolean));};
    setWindow();
  },[temp, temp2, temp3]);
  
  useEffect(() => {
    const getData = async () => {
      try {
        const requestBody = { "fileType": ".feature" };
        const result = await postData('get-fileList', requestBody);

        const requestStepBody = { "fileType": ".java" };
        const resultStep = await postData('get-fileList', requestStepBody);

        testData = await fetchData('get-Excel'); 
        setTestData(testData);   
            
        for (const feature of result.fileList) {          
          const fileContent = await postData('get-fileContent', {"filePath":feature});
          newMap.set(feature, fileContent);
        }
        for (const step of resultStep.fileList) {          
          const stepContent = await postData('get-fileContent', {"filePath":step});
          newMap.set(step, stepContent);
        }
        for (const featureData of Object.keys(testData)) {  
          newMap.set(featureData+'_Data', testData[featureData]);          
        }        
        setData(newMap);
      } catch (error) {
        console.error('Error fetching data:', error.message);
      }
    };
    getData();
  }, []);

  
  const checkOnChange = (value) => {
    //future enhancement 
  };

  const handleFileChange = (item, value) => { 
    setUpdateMap(updateMap =>updateMap.set(item,value));
  };

  const pushCode = async () => {
    setLoading(true);
    const numberOfKeys = [...updateMap.keys()].filter(key => key.includes('_Data')).length;
    let count = 0;
    for (const [key, value] of updateMap) {
      var status;
      if (key.includes('_Data')) {
        var customKey = key.replace('_Data', '');
        var testData = testDataState;
        testData[customKey] = JSON.parse(value);
        setTestData(testData);
        count++;
        if (count === numberOfKeys) {
          status = await postData('create-Excel', testDataState);
        }
      } else {
        status = await postData('set-fileContent', { "filePath": key, "feature": value });
      }      
      status.Status === true ? toast.success(key + ' : File updated successfully!!!'):
    toast.error('File not updated');               
    } 
    setLoading(false);    
  }; 
  

  const runScript = async() => {
    setLoading(true);
    const status = await fetchData('run');
    setLoading(false);
    status.Status === true ? toast.success('Automation Script Executed successfully!!!'):
    toast.error('Script Execution Failed');    
  };
 

  return (    
    <div className="w-full-2 mt-6 mx-5 p-2 md:p-5  bg-white dark:text-gray-200 dark:bg-secondary-dark-bg rounded-3xl">
      <Header category="IACETAF" title="Intelligent Ace Test Automation Framework"/>      
      <div className='flex flex-wrap gap-4 justify-start'>      
      <div>        
        <h1 className='font-bold text-xl text-center' color='grey'>{"Features"} </h1> 
          <MultiSelect dynWin={handleFeatureWindow}
          listname={"Feature"}
          list={Array.from(data.keys()).filter(key => key.includes('.feature'))}   
          onChange={checkOnChange} />        
      </div>
      <div> 
        <h1 className='font-bold text-xl text-center' color='grey'>{"StepDefinition"}</h1> 
        <MultiSelect dynWin={handleStepWindow}
          listname={"StepDef"}
          list={Array.from(data.keys()).filter(key => key.includes('.java'))}    
          onChange={checkOnChange} />      
      </div>
      <div>
        <h1 className='font-bold text-xl text-center' color='grey'>{"TestData"}</h1> 
        <MultiSelect dynWin={handleDataWindow}
          listname={"TestData"}
          list={Array.from(data.keys()).filter(key => key.includes('_Data'))}    
          onChange={checkOnChange}/>        
      </div>
    </div>
    <div className="flex gap-2 my-4">
      {
        windowList ? 
        windowList.map((item, index) => (
            <div key={index} className="flex" style={{ width: `${100 / windowList.length}%` }}>
              <CodeEditor
              value={item.includes('_Data')? JSON.stringify(data.get(item), null, 2):data.get(item).fileContent}
              onChange={(value) => handleFileChange(item, value)}/>              
            </div>
          )) 
        : 
        <h1></h1>
      }  
    </div>
    <div className="flex mt-6 justify-evenly">
        <Button onClick={pushCode}
          color="white"
          bgColor={currentColor}
          text="Save"
          borderRadius="10px"
          />   
          <Button onClick={runScript}
          color="white"
          bgColor={currentColor}
          text="Run"
          borderRadius="10px">
          </Button>  
      </div>
      <Toaster richColors position='top-center'
          toastOptions={{
            classNames: {
              error: 'bg-red-400',
              success: 'text-green-400',
              warning: 'text-yellow-400',
              info: 'bg-blue-400',              
            },
          }}
        />
      {loading? <GridLoader color="#36d7b7" 
      loading = {true}/>:''}
    </div> );
};
export default IACETAF;