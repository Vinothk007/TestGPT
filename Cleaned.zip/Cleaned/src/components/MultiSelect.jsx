import { useState, useEffect, useRef, createContext } from 'react';
import { postData } from '../apis/apiServices';
import TextPopup from './TextPopup';
import { Toaster, toast } from 'sonner';

export const winList = createContext();

const MultiSelect = ({onChange,listname,list,dynWin}) => {
  const [selectedOptions, setSelectedOptions] = useState([]);
  const [showPopup, setShowPopup] = useState(false);
  const [fileName, setFileName] = useState();
    
  const handleChange = (e) => {
    const isChecked = e.target.checked;
    const option = e.target.value;  
    const selectedOptionSet = new Set(selectedOptions);
  
    if (isChecked) {
      selectedOptionSet.add(option);      
    } else {
      selectedOptionSet.delete(option);
    }
    //dynWin(Array.from(selectedOptionSet));
    const newSelectedOptions = Array.from(selectedOptionSet);        
    setSelectedOptions(newSelectedOptions);
    dynWin(newSelectedOptions);
    onChange(newSelectedOptions);  
  };
  

  const isSelectAllEnabled = selectedOptions.length < list.length;
  const isClearSelectionEnabled = selectedOptions.length > 0;
  const optionsListRef = useRef(null);

  const handleSelectAllClick = (e) => {
    e.preventDefault();  
    const optionsInputs = optionsListRef.current.querySelectorAll("input");
    optionsInputs.forEach((input) => {
      input.checked = true;
    });  
    setSelectedOptions([...list]);
    onChange([...list]);
    dynWin([...list]);
  };
  
  const handleClearSelectionClick = (e) => {
    e.preventDefault();  
    const optionsInputs = optionsListRef.current.querySelectorAll("input");
    optionsInputs.forEach((input) => {
      input.checked = false;
    });  
    setSelectedOptions([]);
    onChange([]);
    dynWin([]);
  };

  const handleFileDeletion = async(e) => {
    e.preventDefault();
    console.log('for delete inside multiselect ' , selectedOptions);
    var fileToDelete = selectedOptions;
    fileToDelete.map(async (file) => {
      const status = await postData('delete-File', {"filePath":file});
      console.log('FileDelete Status ',status);
      console.log('FileDelete Status ',status.Status);
      status.Status === true ? toast.success(fileToDelete+' : File Deleted successfully!!!')
      :toast.error('File not Deleted');
    });
  };

  const handleFileAddition = async(e) => {
    e.preventDefault();    
    console.log('File Addition inside multiselect ' , fileName);
    var fileToAdd = fileName;
    const status = await postData('add-File', {"filePath":fileToAdd});
    console.log('FileAdded Status ',status);
    status.Status === true ? toast.success('File created successfully!!!'): //Error need to debug
    toast.error('File not created');
  };

  const handleAddFile = () => {
  setShowPopup(true);  
  };
  
return (
  <div>    
    <label>    
        <input type="checkbox" className="hidden peer" />
          <div className="flex justify-evenly cursor-pointer bg-gray-400 after:content-['▼'] after:text-xs after:ml-7 after:inline-flex after:items-center peer-checked:after:-rotate-180 after:transition-transform shadow-2xl drop-shadow-md rounded-t-md">
          {"Select "+listname}
          </div>
        <div className="absolute bg-gray-300 border-2 border-gray-500 transition-opacity opacity-0 pointer-events-none peer-checked:opacity-100 peer-checked:relative peer-checked:pointer-events-auto z-30">
        <ul ref={optionsListRef}>
        <ul>
          <li>
            <button
              onClick={handleSelectAllClick}
              disabled={!isSelectAllEnabled}
              className="w-full text-left px-2 py-1 text-blue-600 disabled:opacity-50"
            >
              {"Select All"}
            </button>
          </li>          
          <li>
            <button
              onClick={handleClearSelectionClick}
              disabled={!isClearSelectionEnabled}
              className="w-full text-left px-2 py-1 text-blue-600 disabled:opacity-50"
            >
              {"Clear selection"}
            </button>
          </li>          
        </ul>
          {list.map((option, i) => {
            return (
              <li key={option}>
                <label className="flex whitespace-nowrap  cursor-pointer px-2 py-1 transition-colors hover:bg-blue-200 [&:has(input:checked)]:bg-blue-200  text-slate-900">
                  <input
                    type="checkbox"
                    name={"Feature"}
                    value={option}
                    className="cursor-pointer"
                    onChange={handleChange}
                  />
                  <span className="ml-1">{option}</span>
                </label>
              </li>              
            );
          })}
          <ul className='h-6 flex'>       
            <button
              onClick={handleAddFile}
              className="w-full text-14 text-white hover:scale-95 border-1 border-gray-200 bg-main-dark-bg rounded-md">
              {"Add"}
            </button>            
            <button
              onClick={handleFileDeletion}
              className="w-full text-14 text-white hover:scale-95 border-1 border-gray-200 bg-main-dark-bg rounded-md">
              {"Delete"}
            </button>
          </ul>
        </ul>        
      </div>       
    </label>
    {showPopup && 
    <TextPopup 
    onClose={()=>setShowPopup(false)} 
    onChange={(event)=>setFileName(event.target.value)}
    onSubmit = {handleFileAddition}/>}
    </div>
  );  
};
 
export default MultiSelect;