import React from 'react';
import { Toaster, toast } from 'sonner'

function ToasterPopup(props) {
    return props.status === 'true'?(
      <div>
        <Toaster position='top-center'/>
        {toast.success(JSON.stringify(props.msg))}
      </div>
    ):(
      <div>
        <Toaster position='top-center'/>
        {toast.error(JSON.stringify(props.msg))}
      </div>
    )
  }

export default ToasterPopup;