import React, { useRef, useState } from 'react'
import { X, FilePlus2 } from 'lucide-react';
import { useStateContext } from '../contexts/ContextProvider';



function TextPopup({onClose, onChange, onSubmit}) {
  const popupRef = useRef(); 
  const { currentColor, currentMode } = useStateContext();  

  const closeModel = (e)=>{
    if(popupRef.current === e.target){
      onClose();
    }
  };

  return (
    <div ref={popupRef} onClick={closeModel} className='fixed inset-0 bg-black bg-opacity-20 backdrop-blur-sm flex justify-center items-center'>
      <div className='mt-10 flex flex-col gap-0 text-white'>
        <button onClick={onClose} className='place-self-end hover:scale-75'><X size={25}/></button>
        <div style={{ backgroundColor: currentColor }} className='rounded-xl px-10 py-10 flex-col'>
          <div className='flex gap-10 mx-1'>
            <h1 className='text-xl font-extrabold text-left w-full'>Enter the File Name</h1>
            <form > 
              <input
                type='text'
                onChange={onChange}
                placeholder='.feature/.java/excel...'
                required 
                className='w-72 px-2 py-1 text-black'/> 
            </form>
          </div>                   
          </div>
          <div className='self-end'>    
            <button onClick = {onSubmit} className='hover:scale-95 flex'><FilePlus2 className='mt-1' size={15}/>Create</button>  
          </div>
        </div>
    </div>
  )
}

export default TextPopup;