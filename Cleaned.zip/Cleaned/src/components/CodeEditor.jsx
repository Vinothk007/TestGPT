import React, { useState } from 'react';
import Editor from '@monaco-editor/react';

const CodeEditor = ({value, onChange}) => { 
    return (    
        <Editor className='absolute h-full'
            height="500px" 
            theme="vs-dark" 
            defaultLanguage="java" 
            // defaultValue={value} 
            value={value} 
            onChange={onChange}           
            //style={{ width: '100%' }}
        />    
    );
}

export default CodeEditor;